// Controls frame image quality -> directly proportional to frame image size
export const OUTPUT_FRAME_WIDTH = 800;
export const OUTPUT_FRAME_QUALITY = 100;
export const FRAMES_SDK_API = "https://airstack-frames-sdk.vercel.app";
