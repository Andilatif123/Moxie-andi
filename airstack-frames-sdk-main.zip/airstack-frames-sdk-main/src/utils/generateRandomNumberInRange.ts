export const generateRandomNumberInRange = (start: number, end: number) =>
  Math.floor(Math.random() * end) + start;
