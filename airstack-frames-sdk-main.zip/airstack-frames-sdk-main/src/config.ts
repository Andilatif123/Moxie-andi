import { ConfigType } from "./types";

export const config: ConfigType = {
  authKey: "",
};
